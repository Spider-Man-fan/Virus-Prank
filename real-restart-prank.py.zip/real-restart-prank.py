#!/usr/bin/env python3
"""
Harmless fun prank - Realistic fullscreen fake BSOD + real restart
Password: Ad(am1
To cancel the restart after it starts: shutdown /a
"""

import tkinter as tk
import subprocess
import time
import sys

PASSWORD = "Ad(am1"

def main():
    # Password check
    print("Enter password to continue: ", end="", flush=True)
    password = input().strip()
    if password != PASSWORD:
        print("Access denied.")
        time.sleep(2)
        sys.exit(1)

    # Create fullscreen fake BSOD window
    root = tk.Tk()
    root.title("Windows")
    root.configure(bg="#0078D7")  # Windows blue
    root.attributes("-fullscreen", True)
    root.attributes("-topmost", True)
    root.overrideredirect(True)
    root.config(cursor="none")

    # BSOD text
    text = """

:(

Your PC ran into a problem and needs to restart. We're just collecting some error info, and then we'll restart for you.

{progress}% complete

For more information about this issue and possible fixes, visit
https://www.windows.com/stopcode

If you call a support person, give them this info:
Stop code: CRITICAL_PROCESS_DIED
"""

    label = tk.Label(
        root,
        text=text.format(progress=0),
        fg="white",
        bg="#0078D7",
        font=("Segoe UI", 24),
        justify="left",
        anchor="nw",
        padx=100,
        pady=80
    )
    label.pack(fill="both", expand=True)

    progress = 0

    def update_progress():
        nonlocal progress
        progress += 1
        if progress > 100:
            progress = 100
            root.after(500, finish)
            return
        label.config(text=text.format(progress=progress))
        root.after(80, update_progress)

    def finish():
        root.destroy()
        # Schedule real restart (30 seconds)
        subprocess.run(
            ["shutdown", "/r", "/t", "30", "/c", "ERROR! Critical system failure - restarting!"],
            shell=True,
            capture_output=True
        )
        print("\nRestart scheduled in 30 seconds.")
        print("To cancel, open Command Prompt and type: shutdown /a")
        time.sleep(3)

    root.after(500, update_progress)
    root.mainloop()

if __name__ == "__main__":
    main()
